package com.royrafles.menufragment;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.FrameLayout;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.navigation.NavigationBarView;

public class MainActivity extends AppCompatActivity {
    private BottomNavigationView bnvNavigasiBottom;
    private FrameLayout flContainer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        bukaFragment(new OjekMotorFragment());
        getSupportActionBar().setTitle("Ojek Motor");

        bnvNavigasiBottom = findViewById(R.id.bnv_navigasi_bottom);
        flContainer = findViewById(R.id.fl_container);

        bnvNavigasiBottom.setOnItemSelectedListener(new NavigationBarView.OnItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                Fragment FR;

                switch (item.getItemId()){
                    case R.id.menu_ojek_motor:
                        bukaFragment(new OjekMotorFragment());
                        getSupportActionBar().setTitle("Ojek Motor");
                        return true;
                    case R.id.menu_ojek_mobil:
                        bukaFragment(new OjekMobilFragment());
                        getSupportActionBar().setTitle("Ojek Mobil");
                        return true;
                    case R.id.menu_ojek_makanan:
                        bukaFragment(new OjekMakananFragment());
                        getSupportActionBar().setTitle("Ojek Makanan");
                        return true;
                }

                return true;
            }
        });
    }

    // method menukar tukar fragment
    private void bukaFragment(Fragment FRG){
        FragmentManager FM = getSupportFragmentManager();
        FragmentTransaction FT = FM.beginTransaction();
        FT.replace(R.id.fl_container, FRG);
        FT.commit();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_too_right, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if(item.getItemId() == R.id.menu_about){
            Intent move = new Intent(MainActivity.this, AboutActivity.class);
            startActivity(move);
        }
        return super.onOptionsItemSelected(item);
    }
}
