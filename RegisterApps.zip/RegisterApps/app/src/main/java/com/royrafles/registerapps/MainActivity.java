package com.royrafles.registerapps;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity {
    Button button;
    ImageView imageView;
    EditText mgmail, mnama, mnpm, mbidang, mangkatan;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        imageView=findViewById(R.id.gambarhima);
        mgmail=findViewById(R.id.xgmail);
        mnama=findViewById(R.id.xnama);
        mnpm=findViewById(R.id.xnpm);
        mbidang=findViewById(R.id.xbidang);
        mangkatan=findViewById(R.id.xangkatan);

        button=findViewById(R.id.tblsubmit);

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String gmail = mgmail.getText().toString();
                String nama = mnama.getText().toString();
                String npm = mnpm.getText().toString();
                String bidang = mbidang.getText().toString();
                String angkatan = mangkatan.getText().toString();

                if(gmail.isEmpty()){
                    mgmail.setError("Field ini Tidak Boleh Kosong");
                    return;
                }

                if(nama.isEmpty()){
                    mnama.setError("Field ini Tidak Boleh Kosong");
                    return;
                }

                if(npm.isEmpty()){
                    mnpm.setError("Field ini Tidak Boleh Kosong");
                    return;
                }

                if(bidang.isEmpty()){
                    mbidang.setError("Field ini Tidak Boleh Kosong");
                    return;
                }

                if(angkatan.isEmpty()){
                    mangkatan.setError("Field ini Tidak Boleh Kosong");
                    return;
                }

                Intent intent=new Intent(MainActivity.this, MainActivity2.class);
                intent.putExtra("gmail",gmail);
                intent.putExtra("nama", nama);
                intent.putExtra("npm",npm);
                intent.putExtra("bidang", bidang);
                intent.putExtra("angkatan",angkatan);
                intent.putExtra("gambar", R.drawable.himakom);
                startActivity(intent);
            }
        });
    }
}