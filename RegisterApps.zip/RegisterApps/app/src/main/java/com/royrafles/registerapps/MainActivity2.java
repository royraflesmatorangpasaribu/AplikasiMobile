package com.royrafles.registerapps;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

public class MainActivity2 extends AppCompatActivity {
    ImageView imageView;
    TextView mgmail, mnama, mnpm, mbidang, mangkatan;

    String xgmail = "gmail";
    String xnama = "nama";
    String xnpm = "npm";
    String xbidang = "bidang";
    String xangkatan = "angkatan";
    String gmail, nama, npm, bidang, angkatan;
    String gambar = "gambar";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        //menerima sesuaikan dengan id di xml 2
        imageView = findViewById(R.id.gambarmasuk);
        mgmail = findViewById(R.id.gmailmhs);
        mnama = findViewById(R.id.namamhs);
        mnpm = findViewById(R.id.npmmhs);
        mbidang = findViewById(R.id.bidangmhs);
        mangkatan = findViewById(R.id.angkatanmhs);

        //untuk membuka yang dikirimkan pada activity 1
        Bundle bundle=getIntent().getExtras();
        gmail=bundle.getString(xgmail);
        nama= bundle.getString(xnama);
        npm = bundle.getString(xnpm);
        bidang = bundle.getString(xbidang);
        angkatan = bundle.getString(xangkatan);

        //tampilin gambar
        int tampilkangbr = bundle.getInt(gambar);
        mgmail.setText(gmail);
        mnama.setText(nama);
        mnpm.setText(npm);
        mbidang.setText(bidang);
        mangkatan.setText(angkatan);
        imageView.setImageResource(tampilkangbr);
    }

    public void websiteHimakom(View view){
        String url="https://himakom.fmipa.unila.ac.id";
        Intent bukaBrowser = new Intent(Intent.ACTION_VIEW);
        bukaBrowser.setData(Uri.parse(url));
        startActivity(bukaBrowser);
    }
}