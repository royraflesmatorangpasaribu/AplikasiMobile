package com.royrafles.loginfragment;

public interface CallbackFragment {
    void changeFragment();
}
